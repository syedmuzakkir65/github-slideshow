//canvas object
let canv = {
    w: 600,
    h: 600,
    col: "#5c615e"
}